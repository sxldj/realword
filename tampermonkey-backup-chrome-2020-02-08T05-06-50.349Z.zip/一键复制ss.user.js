// ==UserScript==
// @name         一键复制ss
// @namespace    https://free-ss.site/
// @version      0.1
// @description  复制所有ss
// @author       long
// @match        https://free-ss.site/
// @grant        none
// ==/UserScript==

(

    function() {
        'use strict';
            var MyDiv =document.getElementsByClassName("container")[0];
            var button = document.createElement("input");
            button.setAttribute("type", "button");
            button.setAttribute("value", '复制');
            button.setAttribute("id", 'copy_all');
            button.setAttribute("class", 'copy');
            button.addEventListener("click",function(){
                var dt=$('#tbss').DataTable();
                var dd=dt.data();
                var dl=dd['length'];
                console.log(dl)
                var ss = typeof dl;
                console.log(ss)
                var all_str='';
                for (var i=0;i<dl;i++)
                {
                    var data=dd[i];
                    all_str+= 'ss://'+CryptoJS.enc.Base64.stringify(CryptoJS.enc.Utf8.parse(data[4]+':'+data[3]+'@'+data[1]+':'+data[2]));
                    all_str+='\r\n';
                }
                const textarea = document.createElement("textarea")
                textarea.style.position = 'fixed'
                textarea.style.top = 0
                textarea.style.left = 0
                textarea.style.border = 'none'
                textarea.style.outline = 'none'
                textarea.style.resize = 'none'
                textarea.style.background = 'transparent'
                textarea.style.color = 'transparent'

                textarea.value = all_str
                document.body.appendChild(textarea)
                textarea.select()
                try {
                    const msg = document.execCommand('copy') ? 'successful' : 'unsuccessful'
                    alert(msg)
                } catch (err) {
                    alert('unable to copy'+err)
                }

            });
            MyDiv.appendChild(button);
    }


)();
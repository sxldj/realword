// ==UserScript==
// @name         一键复制
// @namespace    https://usky.ml/tool/free_ssr
// @version      0.1
// @description  复制所有
// @author       long
// @match        https://usky.ml/tool/free_ssr
// @grant        none
// @require      https://cdn.jsdelivr.net/npm/clipboard@2/dist/clipboard.min.js
// ==/UserScript==

(
    function() {
        'use strict';
        var copy_all = {
            download: function (MyDiv) {
                var ip1=$("input.layui-input")[0];
                $.get("api/free_ssr?page="+ip1.value+"&limit=10", function(result){
                    var data=result["data"];
                    var dl=data['length'];
                    var all_strss='';
                    var all_strssr='';
                    for (var i=0;i<dl;i++)
                    {
                        var ddd=data[i];
                        all_strss+=ddd['sslink'];
                        all_strss+='\r\n';
                        all_strssr+=ddd['ssrlink'];
                        all_strssr+='\r\n';
                    }
                    MyDiv.innerHTML='<li class="layui-nav-item"><a class="copy" data-clipboard-text="'+all_strss+'">复制SS</a></li>'+MyDiv.innerHTML;
                    MyDiv.innerHTML='<li class="layui-nav-item"><a class="copy" data-clipboard-text="'+all_strssr+'">复制SSR</a></li>'+MyDiv.innerHTML;
                    var clipboard = new ClipboardJS('.copy');
                    clipboard.on('success', function(e) {
                        alert('successful:'+e.action);
                        e.clearSelection();
                    });

                    clipboard.on('error', function(e) {
                        alert('unsuccessful:'+e.action);
                    });
                });

                return ;
            }
        };
        var MyDiv =document.getElementsByClassName("layui-nav layui-bg-cyan")[0];

        MyDiv.innerHTML='<li class="layui-nav-item"><a id="download" >下载数据</a></li>'+MyDiv.innerHTML;
        $("#download").click(function () {
            copy_all.download(MyDiv);
        });

    }


)();